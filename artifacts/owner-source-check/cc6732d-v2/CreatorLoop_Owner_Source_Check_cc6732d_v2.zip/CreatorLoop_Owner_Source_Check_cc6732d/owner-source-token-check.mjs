// Kit-only Owner glue; repository files remain byte-identical to cc6732d.
// Never read a token from argv, environment, a key file, URL or configuration.
import {readFile,lstat,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
export const SOURCE_COMMIT='cc6732dba75b208dae05c886c56af73a4b16f012';
const ROOT=path.dirname(fileURLToPath(import.meta.url));
const SOURCE_FILES=Object.freeze({
 'scripts/lib/cloudflare-readonly.mjs':'c6d50207bd8f7d6436c9f5ad86a8e28abab2f934b6ec84a3c5895b8e4b67fa6b',
 'scripts/lib/cloudflare-token-custody-preflight.mjs':'5c8db9cc13b800714f561c516fb5e3af4155e9afc679ee7d09f58bbb3653c7d4',
 'scripts/acceptance/cloudflare-targets.json':'09f545f0638b483fc7feef59f7fd7458559c4f4ee01e4824d672851f5b825abc',
 'scripts/diagnostics/private-cloudflare-token-preflight.mjs':'4f9b3749826b6b3deb102bcfb41dd51d54d0e82056cb3420f0a1dda744e0d7a9'
});
const INVENTORY=new Set([...Object.keys(SOURCE_FILES),'owner-source-token-check.mjs','Run_Owner_Check.command','OWNER_MAC_README.md','SOURCE_MANIFEST.json','SHA256SUMS']);
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const safeFailure=code=>({protocol:'CREATORLOOP_OWNER_SOURCE_CHECK_CC6732D_V1',sourceCommit:SOURCE_COMMIT,sourceTokenResult:'BLOCKED',code,verificationAttempted:false,httpStatus:0,providerCodes:[],sourceTokenVerified:false,tokenActive:false,scopeVerified:false,resourceAccessVerified:false,installedGitHubSecretVerified:false,backupApproved:false,releaseApproved:false,ownerAuthorizationVerified:false,changesMade:false,networkRequests:0});
async function inventory(dir=ROOT,prefix=''){
 const out=[];
 for(const name of await readdir(dir)){
  const rel=prefix+name,p=path.join(dir,name),s=await lstat(p);
  if(s.isSymbolicLink()||s.uid!==process.getuid()||(s.mode&0o077)!==0)throw Error('KIT_INTEGRITY_BLOCKED');
  if(s.isDirectory())out.push(...await inventory(p,rel+'/'));
  else if(s.isFile()&&INVENTORY.has(rel))out.push(rel);
  else throw Error('KIT_INTEGRITY_BLOCKED');
 }
 return out;
}
export async function validateKit(){
 const root=await lstat(ROOT);
 if(root.isSymbolicLink()||!root.isDirectory()||root.uid!==process.getuid()||(root.mode&0o077)!==0)throw Error('KIT_INTEGRITY_BLOCKED');
 const actual=await inventory();
 if(actual.length!==INVENTORY.size||actual.some(x=>!INVENTORY.has(x)))throw Error('KIT_INTEGRITY_BLOCKED');
 const manifest=JSON.parse(await readFile(path.join(ROOT,'SOURCE_MANIFEST.json'),'utf8'));
 if(manifest.sourceCommit!==SOURCE_COMMIT||manifest.protocol!=='CREATORLOOP_OWNER_SOURCE_KIT_V1'||!Array.isArray(manifest.files)||manifest.files.length!==7)throw Error('KIT_INTEGRITY_BLOCKED');
 const seen=new Set();
 for(const file of manifest.files){
  if(!INVENTORY.has(file.path)||seen.has(file.path)||['SOURCE_MANIFEST.json','SHA256SUMS'].includes(file.path)||!/^[0-9a-f]{64}$/.test(file.sha256))throw Error('KIT_INTEGRITY_BLOCKED');
  seen.add(file.path);
  if(digest(await readFile(path.join(ROOT,file.path)))!==file.sha256)throw Error('KIT_INTEGRITY_BLOCKED');
 }
 for(const [name,hash] of Object.entries(SOURCE_FILES))if(digest(await readFile(path.join(ROOT,name)))!==hash)throw Error('KIT_INTEGRITY_BLOCKED');
 const targets=JSON.parse(await readFile(path.join(ROOT,'scripts/acceptance/cloudflare-targets.json'),'utf8'));
 const {readOnlyClient}=await import('./scripts/lib/cloudflare-readonly.mjs');
 const client=readOnlyClient({token:'FICTIONAL-OFFLINE-CHECK-NEVER-SENT',targets,tokenType:'user',fetcher:async()=>{throw Error('OFFLINE_NETWORK_FORBIDDEN');}});
 if(client.tokenType!=='user'||client.tokenVerificationPath!=='/user/tokens/verify')throw Error('KIT_INTEGRITY_BLOCKED');
 return {integrityVerified:true,sourceCommit:SOURCE_COMMIT,reviewedUserEndpointVerified:true,networkRequests:0,keyReadOrGenerated:false};
}
export async function checkOwnerSource({token,fetcher=globalThis.fetch,now=Date.now}={}){
 const result=safeFailure('PREFLIGHT_BLOCKED');
 if(typeof token!=='string'||token.length===0)return {...result,code:'SOURCE_TOKEN_UNAVAILABLE'};
 try{
  await validateKit();
  const targets=JSON.parse(await readFile(path.join(ROOT,'scripts/acceptance/cloudflare-targets.json'),'utf8'));
  const {readOnlyClient}=await import('./scripts/lib/cloudflare-readonly.mjs');
  const {preflightSourceToken}=await import('./scripts/lib/cloudflare-token-custody-preflight.mjs');
  const selector=readOnlyClient({token,targets,tokenType:'user',fetcher:async()=>{throw Error('RESOURCE_API_FORBIDDEN');}});
  const endpoint='https://api.cloudflare.com/client/v4'+selector.tokenVerificationPath;
  let calls=0;
  const sourceOnlyFetch=async(url,options)=>{
   if(calls!==0||url!==endpoint||selector.tokenType!=='user'||selector.tokenVerificationPath!=='/user/tokens/verify'||options?.method!=='GET'||options.body!==undefined||options.redirect!=='error'||options.credentials!=='omit'||options.cache!=='no-store')throw Error('SOURCE_ENDPOINT_BLOCKED');
   calls++;
   return fetcher(url,options);
  };
  const report=await preflightSourceToken({tokenType:'user',executeReadOnly:true,token,fetcher:sourceOnlyFetch,now});
  token=undefined;
  const failed=report.verificationAttempted&&['CLOUDFLARE_HTTP_ERROR','CLOUDFLARE_API_REJECTED','TOKEN_DISABLED','TOKEN_EXPIRED','TOKEN_NOT_YET_VALID'].includes(report.code);
  return {...result,observedAt:new Date().toISOString(),sourceTokenType:'user',verificationEndpoint:'/user/tokens/verify',sourceTokenResult:report.sourceTokenVerified?'PASS':failed?'FAIL':'BLOCKED',code:report.sourceTokenVerified?'USER_SOURCE_TOKEN_ACTIVE_ONLY':report.code,verificationAttempted:report.verificationAttempted,httpStatus:report.httpStatus,providerCodes:report.providerCodes,sourceTokenVerified:report.sourceTokenVerified,tokenActive:report.tokenActive,networkRequests:calls,reviewedEndpointSelector:'CC6732D_USER_ONLY',liveVerifierIntegrationCertified:false};
 }catch{return {...result,code:'KIT_OR_INPUT_BLOCKED'};}
 finally{token=undefined;}
}
async function privateStdin(){
 const chunks=[];let size=0,combined;
 try{
  for await(const chunk of process.stdin){size+=chunk.length;if(size>4096){chunk.fill(0);throw Error('SOURCE_INPUT_INVALID');}chunks.push(chunk);}
  combined=Buffer.concat(chunks);
  return combined.toString('utf8');
 }finally{for(const chunk of chunks)chunk.fill(0);if(combined)combined.fill(0);}
}
if(process.argv[1]&&pathToFileURL(process.argv[1]).href===import.meta.url){
 let result;
 try{
  const args=process.argv.slice(2);
  if(args.length===1&&args[0]==='--offline-validate')result=await validateKit();
  else if(args.length!==2||args[0]!=='--execute-read-only'||args[1]!=='--token-stdin')result=safeFailure('INVALID_CLI_ARGUMENTS');
  else if(process.platform!=='darwin'||Number(process.versions.node.split('.')[0])!==22)result=safeFailure('OWNER_MAC_NODE22_REQUIRED');
  else{await validateKit();let token=await privateStdin();result=await checkOwnerSource({token});token=undefined;}
 }catch{result=safeFailure('KIT_OR_INPUT_BLOCKED');}
 console.log(JSON.stringify(result));
 process.exitCode=result.integrityVerified||result.sourceTokenVerified?0:1;
}
